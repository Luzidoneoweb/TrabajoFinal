# Instrucciones de Implementación - Modo Lectura Adaptativo

## Descripción de los Cambios

He modificado tus archivos para que `lectura.php` funcione como una página independiente con comportamiento similar a Readlang, donde el contenido se adapta dinámicamente al tamaño de la pantalla.

## Archivos Modificados

### 1. **lectura_modificado.css**
- **Cambios principales:**
  - La página ahora ocupa el 100% del viewport (`height: 100vh`, `position: fixed`)
  - El contenido usa `overflow-y: hidden` para evitar scroll
  - El tamaño de fuente se adapta usando `clamp()` con unidades `vh` (viewport height)
  - Cuando la pantalla es más grande, el texto es más grande, mostrando menos contenido
  - Cuando la pantalla es más pequeña, el texto es más pequeño, mostrando más contenido
  - Media queries específicas para diferentes alturas de pantalla

### 2. **lectura_modificado.php**
- **Cambios principales:**
  - Ahora es una página HTML completa e independiente
  - Incluye `<!DOCTYPE html>` y estructura completa
  - Reset de estilos básicos para eliminar márgenes y padding
  - El botón "Volver" ahora cierra la ventana con `window.close()`

### 3. **lectura_modificado.js**
- **Cambios principales:**
  - Carga el contenido inmediatamente al abrir la página
  - Soporta recibir el ID del texto por URL (`?id=123`)
  - Función para ajustar el tamaño del texto dinámicamente
  - Manejo mejorado del botón "Volver"

## Cómo Implementar

### Opción 1: Reemplazar archivos existentes

```bash
# Reemplazar los archivos originales con los modificados
cp lectura_modificado.css pestanas/css/lectura.css
cp lectura_modificado.php lectura.php
cp lectura_modificado.js pestanas/js/lectura.js
```

### Opción 2: Crear nueva página de lectura

Si prefieres mantener la versión original, puedes crear una nueva página:

```bash
# Crear nueva página de lectura
cp lectura_modificado.php lectura_fullscreen.php
cp lectura_modificado.css pestanas/css/lectura_fullscreen.css
cp lectura_modificado.js pestanas/js/lectura_fullscreen.js
```

Y actualizar las referencias en `lectura_fullscreen.php`:

```html
<link rel="stylesheet" href="pestanas/css/lectura_fullscreen.css">
<script src="pestanas/js/lectura_fullscreen.js"></script>
```

## Cómo Abrir la Página de Lectura

### Desde tu aplicación principal

Modifica el enlace o botón que abre la lectura para que abra en una nueva ventana:

```javascript
// Opción 1: Abrir en nueva pestaña
function abrirLectura(textId) {
    localStorage.setItem('currentTextId', textId);
    window.open('lectura.php', '_blank');
}

// Opción 2: Abrir en nueva ventana con tamaño específico
function abrirLectura(textId) {
    localStorage.setItem('currentTextId', textId);
    window.open('lectura.php?id=' + textId, 'Lectura', 'width=1200,height=800');
}

// Opción 3: Abrir en pantalla completa
function abrirLectura(textId) {
    localStorage.setItem('currentTextId', textId);
    const ventana = window.open('lectura.php?id=' + textId, '_blank');
    if (ventana) {
        ventana.moveTo(0, 0);
        ventana.resizeTo(screen.width, screen.height);
    }
}
```

### Ejemplo de HTML

```html
<button onclick="abrirLectura(123)">Leer Texto</button>
```

## Características del Comportamiento Adaptativo

### Adaptación por Altura de Pantalla

- **Pantallas muy altas (>900px):** Texto más grande (hasta 4rem)
- **Pantallas normales (600-900px):** Texto medio (1.5-3.5rem)
- **Pantallas bajas (<600px):** Texto más pequeño (1-2rem)

### Adaptación por Ancho de Pantalla

- **Pantallas grandes (>1400px):** Texto muy grande con más espacio
- **Pantallas medianas (768-1400px):** Texto estándar
- **Pantallas pequeñas (<768px):** Texto adaptado para móviles

### Fórmula de Adaptación

El tamaño del texto usa la función CSS `clamp()`:

```css
font-size: clamp(mínimo, preferido, máximo);
```

Por ejemplo:
```css
font-size: clamp(1.2rem, 3vh, 3.5rem);
```

Esto significa:
- **Mínimo:** 1.2rem (nunca será más pequeño)
- **Preferido:** 3vh (3% de la altura del viewport)
- **Máximo:** 3.5rem (nunca será más grande)

## Pruebas Recomendadas

1. **Probar en diferentes tamaños de ventana:**
   - Redimensiona la ventana del navegador
   - El texto debe ajustarse automáticamente
   - Menos texto visible cuando la ventana es más grande

2. **Probar en diferentes dispositivos:**
   - Desktop: Texto grande, menos contenido visible
   - Tablet: Texto medio
   - Móvil: Texto más pequeño, más contenido visible

3. **Probar la funcionalidad:**
   - Botón "Volver" debe cerrar la ventana
   - Botones de navegación (Anterior/Siguiente)
   - Botón de reproducción

## Notas Importantes

- **Respeta el diseño original:** Todos los botones y elementos visuales se mantienen
- **Sin cambios en la imagen:** El diseño visual es el mismo, solo cambia la adaptación del tamaño
- **Comportamiento tipo Readlang:** El contenido se adapta al viewport como en Readlang
- **Compatible con navegadores modernos:** Usa características CSS modernas (clamp, vh, vw)

## Solución de Problemas

### El texto no se adapta

Verifica que el CSS esté correctamente vinculado:
```html
<link rel="stylesheet" href="pestanas/css/lectura.css">
```

### La ventana no se cierra

El botón "Volver" solo puede cerrar ventanas abiertas con `window.open()`. Si abres la página directamente, redirigirá a `index.php`.

### El contenido no carga

Verifica que:
1. El archivo `get_lectura_data.php` esté en la ruta correcta
2. El ID del texto se pase correctamente por URL o localStorage
3. La base de datos esté configurada correctamente

## Soporte

Si necesitas más ajustes o tienes preguntas, no dudes en contactarme.
