// pestanas/js/lectura.js
// Modificado para funcionar en página independiente

document.addEventListener('DOMContentLoaded', function() {
    // Cargar el contenido inmediatamente al abrir la página
    cargarContenidoLectura();

    // Función para cargar el contenido del texto
    function cargarContenidoLectura() {
        // Obtener el ID del texto desde la URL o localStorage
        const urlParams = new URLSearchParams(window.location.search);
        let textId = urlParams.get('id') || localStorage.getItem('currentTextId');
        
        // Para propósitos de prueba, si no hay un ID, usar un ID predefinido (ej. 1)
        if (!textId) {
            console.warn('No se encontró el ID del texto. Intentando cargar el texto con ID 1 para prueba.');
            textId = 1; // ID de texto de prueba
        }

        fetch(`pestanas/php/get_lectura_data.php?id=${textId}`, { credentials: 'include' })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    const texto = data.data;
                    document.querySelector('.titulo-lectura').textContent = texto.title;
                    document.querySelector('.frase-original .contenido-texto p').innerHTML = (texto.content || '').replace(/\n/g, '<br>');
                    document.querySelector('.frase-traduccion .texto-traduccion').innerHTML = (texto.content_translation || 'Sin traducción').replace(/\n/g, '<br>');
                    
                    // Ajustar el tamaño del texto dinámicamente según el viewport
                    ajustarTamanoTexto();
                    
                    console.log('Texto cargado:', texto.title);
                } else {
                    console.error('Error al cargar el texto:', data.error);
                    document.querySelector('.titulo-lectura').textContent = 'Error al cargar';
                    document.querySelector('.frase-original .contenido-texto p').textContent = `No se pudo cargar el texto: ${data.error}`;
                    document.querySelector('.frase-traduccion .texto-traduccion').textContent = '';
                }
            })
            .catch(error => {
                console.error('Error en la petición fetch para cargar el texto:', error);
                document.querySelector('.titulo-lectura').textContent = 'Error de conexión';
                document.querySelector('.frase-original .contenido-texto p').textContent = `Error de red: ${error.message}`;
                document.querySelector('.frase-traduccion .texto-traduccion').textContent = '';
            });
    }

    // Función para ajustar el tamaño del texto según el viewport
    function ajustarTamanoTexto() {
        // Esta función se puede expandir para ajustes más específicos si es necesario
        // El CSS ya maneja la mayoría de la adaptación con clamp() y vh/vw
        window.addEventListener('resize', function() {
            // Forzar recalculo de estilos si es necesario
            document.querySelector('.zona-frases').style.display = 'none';
            setTimeout(function() {
                document.querySelector('.zona-frases').style.display = 'flex';
            }, 10);
        });
    }

    // Manejar el botón de volver
    const btnVolver = document.querySelector('.btn-volver');
    if (btnVolver) {
        btnVolver.addEventListener('click', function() {
            // Intentar cerrar la ventana
            window.close();
            
            // Si no se puede cerrar (porque no fue abierta con window.open), 
            // redirigir a la página principal
            setTimeout(function() {
                if (!window.closed) {
                    window.location.href = 'index.php';
                }
            }, 100);
        });
    }
});
